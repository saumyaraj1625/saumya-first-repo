<?php
// Database details (Jo aapne cPanel MySQL Wizard mein banaye the)
$host = "localhost";
$user = "growthhs_AgriHub"; // Aapka Database Username
$pass = "growthhs_AgriHub"; // Aapka Database Password
$dbname = "growthhs_AgriHub"; // Aapka Database Name

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>