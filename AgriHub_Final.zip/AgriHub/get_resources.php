<?php
header('Content-Type: application/json');

// --- DATABASE CONNECTION (Apni details bharein) ---
$host = "localhost";
$user = "growthhs_AgriHub"; // Aapka cPanel DB Username
$pass = "growthhs_AgriHub"; // Aapka cPanel DB Password
$dbname = "growthhs_AgriHub"; // Aapka cPanel DB Name

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Connection failed"]));
}

// Data select karein (Latest items pehle dikhenge)
$sql = "SELECT * FROM resources ORDER BY id DESC";
$result = $conn->query($sql);

$resources = [];
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $resources[] = $row;
    }
}

echo json_encode($resources);
$conn->close();
?>