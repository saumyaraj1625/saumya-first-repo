<?php
include 'config.php';
header('Content-Type: application/json');

$title = $_POST['title'];
$labor = $_POST['labor'];
$farmer = $_POST['farmer'];
$expert = $_POST['expert'];
$desc = $_POST['description'];
$owner = $_POST['owner'];

$sql = "INSERT INTO projects (title, labor_needed, farmer_needed, expert_needed, description, owner_name) 
        VALUES ('$title', '$labor', '$farmer', '$expert', '$desc', '$owner')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => $conn->error]);
}
?>