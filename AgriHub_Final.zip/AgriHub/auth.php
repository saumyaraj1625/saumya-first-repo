<?php
include 'config.php';
header('Content-Type: application/json');

$action = $_POST['action'] ?? 'login';
$phone  = $conn->real_escape_string($_POST['phone'] ?? '');
$password = $_POST['password'] ?? '';

// ─── SIGNUP ───────────────────────────────────────────────────────────────────
if ($action === 'signup') {
    $role = $conn->real_escape_string($_POST['role'] ?? 'Farmer');
    $name = $role . " User";

    $check = $conn->query("SELECT id FROM users WHERE phone = '$phone'");
    if ($check->num_rows > 0) {
        echo json_encode(["status" => "error", "message" => "Yeh phone number pehle se registered hai. Login karein."]);
        exit;
    }

    $hashed = password_hash($password, PASSWORD_DEFAULT);
    $sql = "INSERT INTO users (name, role, phone, password) VALUES ('$name', '$role', '$phone', '$hashed')";
    if ($conn->query($sql) === TRUE) {
        echo json_encode(["status" => "success", "message" => "Account ban gaya!", "user" => ["name" => $name, "role" => $role]]);
    } else {
        echo json_encode(["status" => "error", "message" => $conn->error]);
    }
    exit;
}

// ─── LOGIN ────────────────────────────────────────────────────────────────────
$result = $conn->query("SELECT * FROM users WHERE phone = '$phone'");

if ($result->num_rows === 0) {
    echo json_encode(["status" => "error", "message" => "Yeh phone number registered nahi hai. Pehle Sign Up karein."]);
    exit;
}

$user = $result->fetch_assoc();

if (!password_verify($password, $user['password'])) {
    echo json_encode(["status" => "error", "message" => "Password galat hai. Dobara try karein."]);
    exit;
}

echo json_encode([
    "status"  => "success",
    "message" => "Logged In",
    "user"    => ["name" => $user['name'], "role" => $user['role'], "phone" => $user['phone']]
]);
?>
