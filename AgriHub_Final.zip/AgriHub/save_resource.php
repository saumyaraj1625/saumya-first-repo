<?php
header('Content-Type: application/json');

// cPanel par details aisi dikhengi (Check your cPanel MySQL Databases)
$host = "localhost"; 
$user = "growthhs_AgriHub"; // Aapka cPanel DB Username
$pass = "growthhs_AgriHub"; // Aapka cPanel DB Password
$dbname = "growthhs_AgriHub"; // Aapka cPanel DB Name

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    // JSON error bhejein taaki JS ko pata chale
    die(json_encode(["status" => "error", "message" => "Database connection failed"]));
}

// ... baaki ka code wahi rahega ...

// 2. Data Receive karein
$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    die(json_encode(["status" => "error", "message" => "No data received"]));
}

// 3. Variables set karein
$category = $conn->real_escape_string($data['category']);
$name = $conn->real_escape_string($data['name']);
$price = (float)$data['price'];
$unit = $conn->real_escape_string($data['unit']);
$location = $conn->real_escape_string($data['location']);
$image = $conn->real_escape_string($data['image']);
$owner = $conn->real_escape_string($data['owner_phone']);

// 4. Query Run karein
$sql = "INSERT INTO resources (category, name, price, unit, location, image_url, owner_phone) 
        VALUES ('$category', '$name', $price, '$unit', '$location', '$image', '$owner')";

if ($conn->query($sql)) {
    echo json_encode(["status" => "success", "message" => "Item added!"]);
} else {
    echo json_encode(["status" => "error", "message" => "SQL Error: " . $conn->error]);
}

$conn->close();
?>